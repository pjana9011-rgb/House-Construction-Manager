# House Construction Manager — Android Studio project

This project wraps the existing bilingual offline web prototype in an Android WebView app.

## Build an APK
1. Install Android Studio (with Android SDK Platform 35 and a compatible JDK).
2. Open this folder (`HouseConstructionManagerAndroid`) in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the generated APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

## Current scope
- English / Bengali toggle
- Offline data stored in the app WebView's local storage
- Six accounting areas matching the uploaded workbook's sheet names: Summary, Materials, Local Labour, Mason & Labour, Others, Contributions
- JSON backup export from the app

## Not yet implemented
- Cloud backup / account sync
- Importing existing Excel rows into the app
- Excel/PDF report export
- Production signing and release APK

The workbook's six sheet names were read from the uploaded XLSX package. Its stylesheet XML is malformed for openpyxl, so cell-level data/formulas were not imported into this prototype.
